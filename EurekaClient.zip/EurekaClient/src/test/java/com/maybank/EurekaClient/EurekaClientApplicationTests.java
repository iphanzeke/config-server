package com.maybank.EurekaClient;


class EurekaClientApplicationTests {

	

}
